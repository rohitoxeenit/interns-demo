<?php

 // create connection
$conn = new mysqli('localhost', 'root', '', 'intern');
 //check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!empty($_POST)){
	//echo "<pre>";
	//print_r($_POST);
	$name =  $_POST['name'];
	$rollno = $_POST['rollno'];
	$email = $_POST['email'];
	$maths = $_POST['maths'];
	$hindi = $_POST['hindi'];
	$english = $_POST['english'];
	$sql = "INSERT INTO form (name, rollno, email,maths,hindi,english ) VALUES ('$name','$rollno','$email','$maths','$hindi','$english')";
	$result = $conn->query($sql);
	if($result){
		echo "Successfully Insert Data";
	} else {
		echo "Opps Record is not inserted";
	}
}
$conn->close();
?>
<center>
<form action="" method="post">  
<h2>PHP  STUDENT Form</h2>

  student Name:  
  <input type="text" name="name">
  <br><br>
  Roll no:  
  <input type="text" name="rollno">
  <br><br>
  E-mail:
  <input type="text" name="email">
  <br><br>
  SUBJECT:
  maths:
  <input type="TEXT" name="maths">
  
  hindi:
  <input type="TEXT" name="hindi">
 
  eng:
  <input type="TEXT" name="english">
  <br><br> 
  <input type="submit" value="Submit">
   
  <br><br> 
   </form>
</center>
</body>
</html>