<?php

	$conn = new mysqli('localhost', 'root', '', 'intern');
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$sql_select = "SELECT * FROM form";
	$result = $conn->query($sql_select);
	
	if(!empty($_GET['id'])){
		$sql_delete = "DELETE FROM form WHERE id='".$_GET['id']."'";
		$result_delete = $conn->query($sql_delete);
		if($result_delete){
			echo "Record Deleted Successfully";
			header("refresh: 1; url =http://localhost/intern/form2.php");
		} else {
			echo "Try Again";
		}
		/*if(!empty($_POST['editsub'])){
		$sql_updatequery = "UPDATE form SET name='".$_POST['name']."', rollno='".$_POST['rollno']."', email='".$_POST['email']."', maths='".$_POST['maths']."',hindi='".$_POST['hindi']."',english='".$_POST['english']."' WHERE id='".$editid."'";
		$result_updatequery = $conn->query($sql_updatequery);
		if($result_updatequery){
			echo "Record UPDATED Successfully";
			header("refresh:2; url=http://localhost/intern/form2.php");
		} else {
			echo "Opps Record is not inserted";
		}*/
	}
 ?>
<!doctype>
<html>
<body> 
	<h2>READ/FETCH/ DISPLAY RECORDS FROM DATABASE</h2>
	<table border="1" width="100%">
		<tr>
			<th>Name</th>
			<th>rollno</th>
			<th>email</th>
			<th>maths</th>
			<th>hindi</th>
			<th>english</th>
			<th>Action</th>
		</tr>
		<?php 
			if ($result->num_rows > 0) {
			foreach($result as $rows){?>
				<tr>
					<td><?php echo $rows['name'];?></td>
					<td><?php echo $rows['rollno'];?></td>
					<td><?php echo $rows['email'];?></td>
					<td><?php echo $rows['maths'];?></td>
					<td><?php echo $rows['hindi'];?></td>
					<td><?php echo $rows['english'];?></td>
					<td><a href="classwork.php?id=<?php echo $rows['id'];?>">EDIT |</a><a href="form2.php?id=<?php echo $rows['id'];?>"> |DELETE</a> </td>
				</tr>
		<?php }}?>
	</table>
</body>
