<!DOCTYPE html>
<html>
<body>
<?php

             //sorting in ascending order
    $cars = array("swift", "alto", "kia");
    sort($cars);
    $clength = count($cars);
    for($x = 0; $x < $clength; $x++) {
    echo $cars[$x];
    echo "<br>";
}
    echo "<br>";
	
	
             // sorting  numbers in ascending order
    $numbers = array(4, 6, 2, 22, 11);
    sort($numbers);

    $arrlength = count($numbers);
    for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}
    echo "<br>";
		
             //  arsort
    $age = array("vinay"=>"35", "mindru"=>"37", "dishu"=>"43");
    arsort($age);

    foreach($age as $x => $x_value) {
    echo "Key=" . $x . ", Value=" . $x_value;
    echo "<br>"; 	
}
              
			  // function arguments 
    echo "<br>";
	function familyName($fname,$year) {
  echo "$fname panwar . born in: $year <br>";
}

familyName("vinay","2004");
familyName("varun","1999");
familyName("kim jong","1960");
familyName("jin ping","1970");
familyName("jackie chan","1960");
 echo "<br>";echo "<br>";
               
			   
			   // since strict is NOT enabled "5 days" is changed to int(5), and it will return 10
function addNumbers( int $a,int $b) {
  return $a + $b;
}
echo addNumbers(5, "5 days");
 echo "<br>";echo "<br>";
 
 
               // PHP Default Argument Value
function setHeight(int $minheight=50) {
  echo "The height is : $minheight <br>";
}

setHeight(350);
setHeight();
setHeight(135);
setHeight(80); 
echo "<br>";


               // PHP Functions - Returning values
function sum($x , $y) {
	$a = $x + $y;
	return $a;
}    
 
  echo "5  + 5 = " . sum(10,10) . "<br>";
  echo "10 + 10 = " . sum(10,10 ) . "<br>";
  echo "20 + 20 = " . sum(20,20) . "<br>";
  echo "30 + 30 = " . sum(30, 30) . "<br>";
  echo "40 + 40 = " . sum(40, 40) . "<br>";
  echo "50 + 50 = " . sum(50, 50) . "<br>";
  echo "60 + 60 = " . sum(60, 60) . "<br>";
  echo "70 + 70 = " . sum(70, 70);
  echo "<br>";
  
?>
  
</body>
</html>
