<!doctype>
<html>
<head>
<style>
      center {
		  border:5px solid black;
          justify-content:center;
	      diplay:flex;
	 }
    
.error {color:#ff0000;}
body { 
      background-image:url("plain.jpg");
}       
</style>
</head>
<body>
<?php
// define variables and set to empty values
$nameErr = $emailErr = $addressErr = $genderErr = $phoneErr = $EDUCATIONErr = $SKILLSErr = "";
$name = $email = $address = $gender = $phone = $EDUCATION = $SKILLS = $file = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (empty($_GET["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_GET["name"]);
  }
    /*// check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }*/
  
  
  if (empty($_GET["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_GET["email"]);
  }
    /*// check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
  }*/
  
	if (empty($_GET["address"])) {
    $addressErr = "required";
  } else {
    $address = test_input($_GET["address"]);
  }

   if (empty($_GET["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_GET["gender"]);
  }

   if (empty($_GET["phone"])) {
    $phoneErr = "phone is required";
  } else {
    $phone = test_input($_GET["phone"]);
  }
   if (empty($_GET["EDUCATION"])) {
    $EDUCATIONErr = "EDUCATION is required";
  } else {
    $EDUCATION = test_input($_GET["EDUCATION"]);
  }
   if (empty($_GET["SKILLS"])) {
    $SKILLSErr = "";
	} else {
    $SKILLS = test_input($_GET["SKILLS"]);
  }
   if (empty($_GET["file"])) {
    $fileErr = "";
	} else {
    $file = test_input($_GET["file"]);
  }
  }
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
 ?> <center>
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  GENDER:
  <input type="radio" name="gender" value="male">male
  <input type="radio" name="gender" value="female">female
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
 address: <textarea name="address" rows="5" cols="40"></textarea>
  <br><br>
  phone:
  <input type="tel" name="phone">
  <span class="error">* <?php echo $phoneErr;?></span>
	<br><br>		
  <label for="pass">EDUCATION:</label>
  <select name="EDUCATION">
	<option value="mca">MCA</option>
	<option value="bca">BCA</option>
	<option value="mba">MBA</option>
	<option value="bba">BBA</option>  
  </select>
  <span class="error">* <?php echo $EDUCATIONErr;?></span>
  <br><br> 
 SKILLS:
  <input type="checkbox" name="SKILLS" value="html">html
  <input type="checkbox" name="SKILLS" value="java script">java script
  <input type="checkbox" name="SKILLS" value="php">php
  <input type="checkbox" name="SKILLS" value="css">css
  <span class="error">* <?php echo $SKILLSErr;?></span>
  <br><br>
  <span class="error">* <?php echo $SKILLSErr;?></span>
  <input type="file" 
  id="resume" value="resume">
  <br><br>
  <input type="submit" name="submit" value="submit">
  <input type="reset"  name="reset"  value="reset">
  </form>
<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $gender;
echo "<br>";
echo $address;
echo "<br>";
echo $phone;
echo "<br>";
echo $EDUCATION;
echo "<br>";
echo $SKILLS;
echo "<br>";
echo $file;
?> </center>

</body>
</html>