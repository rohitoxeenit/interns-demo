<!doctype>
<html>
<head>
<style>
     center {
		  border:5px solid black;
		  justify-content:center;
	      diplay:flex;
	 }
	
.error {color:#ff0000;}
body { 
           background-image:url("purple.jpg");
}
</style>
</head>
<body>
<?php
// define variables and set to empty values
$nameErr = $emailErr =$phoneErr = $addressErr = $genderErr = $EDUCATIONErr = $SKILLSErr = "";
$name = $email = $phone = $address = $gender = $EDUCATION = $SKILLS = $file = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    } 
	   if (empty($_POST["phone"])) {
    $phoneErr = "phone is required";
  } else {
    $phone = test_input($_POST["phone"]);
  }
	
	if (empty($_POST["address"])) {
    $addressErr = "address is required";
  } else {
    $address = test_input($_POST["address"]);
  }

   if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }


   if (empty($_POST["EDUCATION"])) {
    $EDUCATIONErr = "EDUCATION is required";
  } else {
    $EDUCATION = test_input($_POST["EDUCATION"]);
  }
   if (empty($_POST["SKILLS"])) {
    $SKILLSErr = "select atleast one skill";
	} else {
    $SKILLS = test_input($_POST["SKILLS"]);
  }
   if (empty($_POST["file"])) {
    $fileErr = "";
	} else {
    $file = test_input($_POST["file"]);
  }
  }
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
 ?> 
 <center>
 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>


  Name: <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  phone:
  <input type="tel" name="phone">
  <span class="error">* <?php echo $phoneErr;?></span>
	<br><br>		
  GENDER:
  <input type="radio" name="gender" value="male">male
  <input type="radio" name="gender" value="female">female
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
   address: <textarea name="address" rows="5" cols="20"></textarea>
   <span class="error">* <?php echo $addressErr;?></span>
  <br><br>
  
  <label for="pass">EDUCATION:</label>
  <select name="EDUCATION">
	<option value="mca">MCA</option>
	<option value="bca">BCA</option>
	<option value="mba">MBA</option>
	<option value="bba">BBA</option>  
  </select>
  <span class="error">* <?php echo $EDUCATIONErr;?></span>
  <br><br> 
 SKILLS:
  <input type="checkbox" name="SKILLS" value="html">html
  <input type="checkbox" name="SKILLS" value="java script">java script
  <input type="checkbox" name="SKILLS" value="php">php
  <input type="checkbox" name="SKILLS" value="css">css
  <span class="error">* <?php echo $SKILLSErr;?></span>
  <br><br>
  <input type="file" id="resume" value="resume">
  <span class="error">* <?php echo $fileErr;?></span>
  <br><br>
  <input type="submit" name="submit" value="submit">
  <input type="reset" name="reset" value="reset">  
</form>

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $gender;
echo "<br>";
echo $address;
echo "<br>";
echo $phone;
echo "<br>";
echo $EDUCATION;
echo "<br>";
echo $SKILLS;
echo "<br>";
echo $file;

?></center>

</body>
</html>