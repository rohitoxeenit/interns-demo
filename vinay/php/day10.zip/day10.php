<!doctype>
<html>
<body>
<?php
    // do while 
     $x=2;
do {
     echo $x=$x+2;
	 echo "<br>";
 } while($x <=10);
 
     // for loop
 for ($i= 0; $i<=10; $i++) {
	 echo "the product :$i <br>";
 }
 
     //while loop 
      $hp = 1;
while($hp <= 5){
	 echo "<br>";		
	 echo  $hp;
	 $hp=$hp+1; 
}	 	  
 ?>
</body>
</html>