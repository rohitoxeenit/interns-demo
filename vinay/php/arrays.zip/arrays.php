<!doctype>
<html>
<body>
<?php
     $cars = array("alto","maruti","nano");
	 echo "i like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";
	 echo "<br>";
	 echo count($cars);
	 echo "<br>";
	
?>
</body>
</html>