<?php

 // create connection
$conn = new mysqli('localhost', 'root', '', 'intern');
 //check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!empty($_POST)){
	//echo "<pre>";
	//print_r($_POST);
	$name =  $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender = $_POST['gender'];
	$address = $_POST['address'];
	$sql = "INSERT INTO work (name, email, phone, gender, address) VALUES ('$name','$email','$phone','$gender','$address')";
	$result = $conn->query($sql);
	if($result){
		echo "Successfully Insert Data";
	} else {
		echo "Opps Record is not inserted";
	}
	
}
$conn->close();
 ?>
<center>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
  Name:  
  <input type="text" name="name">
  <br><br>
  E-mail:
  <input type="text" name="email">
  <br><br>
  phone:
  <input type="tel" name="phone">
  <br><br>		
  GENDER:
  <input type="radio" name="gender" value="male">male
  <input type="radio" name="gender" value="female">female
  <br><br>
  address: <textarea name="address" rows="5" cols="20"></textarea>
  <br><br>
  <input type="submit" value="Submit">
  </form>
</center>
</body>
</html>