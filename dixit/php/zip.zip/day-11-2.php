<!DOCTYPE html>
<html>
<body>

<?php
$cars = array (
  array("maruti800",22,18),
  array("alto k10",15,13),
  array("nano",5,2),
  array("wagnor",17,15)
);
for ($row = 0; $row < 4; $row++) {
  echo "<p><b>Row number $row</b></p>";
  echo "<ul>";
  for ($col = 0; $col < 3; $col++) {
    echo "<li>".$cars[$row][$col]."</li>";
  }
  echo "</ul>";
  echo "<br/>";
}
    
foreach ($cars as $car_array_keys => $car_value){
	 echo "<pre>";
	 print_r($car_value);
	echo 'Array Key:'.$car_array_keys.' == '.$car_value;
	 echo "<br/>";
 }
?>

</body>
</html>