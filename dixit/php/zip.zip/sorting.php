<!DOCTYPE html>
<html>
<body>

<?php
//sort
$cars = array("Volvo", "BMW", "Toyota");
sort($cars);
echo "<br>";
$clength = count($cars);
for($x = 0; $x < $clength; $x++) {
  echo $cars[$x];
  echo "<br>";
}
//rsort
$numbers = array(4, 6, 2, 22, 11);
rsort($numbers);
$arrlength = count($numbers);
echo "<br>";
for($x = 0; $x < $arrlength; $x++) {
  echo $numbers[$x];
  echo "<br>"; 
}
//asort
$age = array("P"=>"35", "B"=>"37", "J"=>"43");
asort($age);
echo "<br>";
foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}
//arsort
$age = array("d"=>"32", "g"=>"35", "j"=>"48");
arsort($age);
echo "<br>";
foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}
//ksort
$age = array("j"=>"56", "h"=>"63", "d"=>"62");
ksort($age);
echo "<br>";
foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}
//krsort
$age = array("e"=>"32", "y"=>"35", "b"=>"43");
krsort($age);
echo "<br>";
foreach($age as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
}
?>

</body>
</html>
