<!doctype>
<html>
<body>
<?php
function writemsg()  {
echo "SHIMLA wassi";
}
 writemsg();
 echo "<br><br>";
 
  // php function argument
 function friendsName($fname,$year) {
  echo "$fname phadi.born in $year <br><br>";
}

friendsName("vinay","2004");
friendsName("himanshu","2004");
friendsName("ishan","2003");
friendsName("sourabh","2004");
friendsName("tarun","2002");
 echo "<br><br>";
 
 //since strict is NOT enabled "5 days" is changed to int(5), and it will return 10
 function addnumbers (int $a,int $b)   {
return $a+$b;
}
echo addnumbers (5,"5 days");
echo "<br><br>";


//php default argument value

function setHeight(int $minheight = 10) {
  echo "The height is : $minheight <br>";
}

setHeight(270);
setHeight();
setHeight(15);
setHeight(50);
echo"<br>";

// returning values php function
function sum( $a,$b) {
  $d = $a + $b;
  return $d;
}

echo "8 + 8 = " . sum(8,8) . "<br>";
echo "7 + 7 = " . sum(7,7) . "<br>";
echo "6 + 6 = " . sum(6,6) . "<br>";
echo "5 + 5 = " . sum(5,5) . "<br>";
echo "4 + 4 = " . sum(4,4) . "<br>";
echo "3 + 3 = " . sum(3,3) . "<br>";
echo "2 + 2 = " . sum(2,2) . "<br>";
echo "1 + 1 = " . sum(1,1);
echo"<br>";

?>
</body>
</html>