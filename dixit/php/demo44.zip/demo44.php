<!doctype>
<html>
  <h3>even no 1-20</h3>
  
  <body>
  <?php 
$num = 0;  
while($num<20) {
echo "<br>";	
echo "$num";
$num+=2;
}
?>
</body>
</html>