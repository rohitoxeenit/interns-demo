<!doctype>
<html>
<body>
<?php
$sub1= 80;
$sub2= 75;
$sub3= 65;
$sub4= 55;
$sub5= 45;
$total =$sub1+$sub2+$sub3+$sub4+$sub5;
echo $total; 
echo "<br>";
$perc= $total/5;
if($perc>80){
	echo 'A-position';
}  else if($perc>=60){
	echo 'B-position';
}	  else if($perc>=40){
	echo 'c-position';
}   else    {
	echo 'fail';
}
?>
</body>
</html>