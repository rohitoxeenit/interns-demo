<!doctype>
<html>
<body>
<?php
$names=array("MANGO","APPLE","BANANA");
$f= count($names);

for($i=0;$i<$f;$i++);
{
	echo$f[$i];
}
// foreach loop
foreach ($names as $fruits)   {
	echo "<pre>";
	print_r($fruits);
}
	
?>
</body>
</html>