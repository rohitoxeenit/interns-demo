<!doctype>
<html>
<body>
<?php
// do while loop
  $x=1;
  do {
  echo$x=$x+1;
  echo"<br>";
}   while($x<=20);
   echo"<br><br>"; 
//for loop
for($i=0;$i<10;$i++)  {
	  echo"the number :$i <br>";
}	  
 echo"<br><br>";
 // while loop
 $ap=1;
 while($ap <=30) {	 
   echo $ap;
  echo "<br/>";
   $ap=$ap+1;
}
echo"<br><br>";

 


?>
</body>
</html>



 







