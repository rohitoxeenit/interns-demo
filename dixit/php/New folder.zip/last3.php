<?php
	// create connection
	$conn = new mysqli('localhost', 'root', '', 'intern');
	 //check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	$editid = $_GET['id'];
	
	$sql_fetchquery = "SELECT * FROM last1 WHERE id='".$editid."'";
	$result_fetchdata = $conn->query($sql_fetchquery);
	$row = $result_fetchdata -> fetch_assoc();
	
	if(!empty($_POST['editsub'])){
		$sql_updatequery = "UPDATE last1 SET name='".$_POST['name']."', email='".$_POST['email']."', phone='".$_POST['phone']."', email='".$_POST['email']."' WHERE id='".$editid."'";
		$result_updatequery = $conn->query($sql_updatequery);
		if($result_updatequery){
			echo "Record UPDATED Successfully";
			header("refresh:2; url=http://localhost/intern/last2.php");
		} else {
			echo "Opps Record is not inserted";
		}
	}
 ?>
<center>
<form method="POST" action="">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
  name:
  <input type="text" name="name" value="<?php echo $row['name'];?>">
  <br><br>
  email:
  <input type="tel" name="email" value="<?php echo $row['email'];?>">
  <br><br>
   rollno:  
  <input type="tel" name="rollno" value="<?php echo $row['rollno'];?>">
  <br><br>	
   SUBJECT:
  css:
  <input type="TEXT" name="css"<?php echo $row['css'];?>">
  <br><br>
  php:
  <input type="TEXT" name="php"<?php echo $row['php'];?>">
 <br><br>
  html:
  <input type="TEXT" name="html"<?php echo $row['html'];?>">
  <br><br> 
  <input type="submit" value="Submit">
   
  <input type="submit" value="Submit" name="editsub">
  </form>

</center>
</body>
</html>