<?php

 // create connection
$conn = new mysqli('localhost', 'root', '', 'intern');
 //check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!empty($_POST)){
	//echo "<pre>";
	//print_r($_POST);
	$name =  $_POST['name'];
	$rollno = $_POST['rollno'];
	$email = $_POST['email'];
	$css = $_POST['css'];
	$php = $_POST['php'];
	$html = $_POST['html'];
	$sql = "INSERT INTO last1 (name,rollno,email,css,php,html ) VALUES ('$name','$rollno','$email','$css','$php','$html')";
	$result = $conn->query($sql);
	if($result){
		echo "Successfully Insert Data";
	} else {
		echo "Opps Record is not inserted";
	}
	
}
$conn->close();
?>
<center>
<form action="" method="post">  
<h2>PHP  STUDENT Form</h2>

  student Name:  
  <input type="text" name="name">
  <br><br>
  Roll no:  
  <input type="text" name="rollno">
  <br><br>
  E-mail:
  <input type="text" name="email">
  <br><br>
  SUBJECT:
  css:
  <input type="TEXT" name="css">
  <br><br>
  php:
  <input type="TEXT" name="php">
 <br><br>
  html:
  <input type="TEXT" name="html">
  <br><br> 
  <input type="submit" value="Submit">
   
  <br><br> 
   </form>
</center>
</body>
</html>