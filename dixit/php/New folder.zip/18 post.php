<!DOCTYPE HTML>  
<html>
<head>
<link type="text" rel="stylesheet" href="mystyle.css">
<style>
center{
	display:flex;
	justify-content:center;
  border: 1px solid black;
  background-color: lightblue;
  
}

.error {color: #FF0000;}
body{
	background-image: url("black.jfif");
	}
</style>
</head>
<body> 
<center>
<div class ="center">
<?php
// define variables and set to empty values
$nameErr = $emailErr = $GenderErr = $courceErr = $addressErr = $educationErr = $numberErr = $skillsErr = "";
$name = $email = $gender = $address  =$education = $number = $skills = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
 
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
if (empty($_POST["address"])) {
    $address = "";
  } else {
    $address = test_input($_POST["address"]);
  }
  if (empty($_POST["number"])) {
    $number = "";
  } else {
    $number = test_input($_POST["number"]);
  }
   if (empty($_POST["education"])) {
    $education = "";
  } else {
    $education = test_input($_POST["education"]);
  }
     if (empty($_POST["skills"])) {
    $skills = "";
  } else {
    $skills = test_input($_POST["skills"]);
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  number: <input number="tel" name="number">
<span class="error">* <?php echo $numberErr;?></span>
  <br><br>
  address: <textarea name="address" rows="5" cols="40"></textarea>
  <span class="error">* <?php echo $addressErr;?></span>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error">* <?php echo $GenderErr;?></span>
  <br><br>
  
  COURCE:
          <select name="education">
        	<option value="BA">BA</option>
          	<option value="BCA">BCA</option>
          	<option value="MCA">MCA</option>
         	<option value="MCOM">MCOM</option>  
           </select>
		   <span class="error">* <?php echo $courceErr;?></span>
		   <br><br>
		   
		skills:	  
		   <input type="checkbox" name="skills" value="html">html
		   <input type="checkbox" name="skills" value="php">php
		   <input type="checkbox" name="skills" value="css">css
		   <input type="checkbox" name="skills" value="bootstrap">bootsrap
		   <input type="checkbox" name="skills" value="java ">java
		   <span class="error">* <?php echo $skillsErr;?></span>
		   <br><br>
 <input type="submit" name="submit" value="Submit">  
 <input type="reset" name="reset" value="reset">  
</form>

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $education;
echo "<br>";
echo $number;
echo "<br>";
echo $address;
echo "<br>";
echo $gender;
echo "<br>";
echo $skills;

?>
</center>
</div>
</body>
</html>