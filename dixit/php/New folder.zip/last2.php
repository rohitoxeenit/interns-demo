<?php
	$conn = new mysqli('localhost', 'root', '', 'intern');
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$sql_select = "SELECT * FROM last1";
	$result = $conn->query($sql_select);
	
	if(!empty($_GET['id'])){
		$sql_delete = "DELETE FROM last1 WHERE id='".$_GET['id']."'";
		$result_delete = $conn->query($sql_delete);
		if($result_delete){
			echo "Record Deleted Successfully";
			header("refresh: 1; url =http://localhost/intern/last2.php");
		} else {
			echo "Try Again";
		}
	}
	

 ?>
<!doctype>
<html>
<head>
</head>
<body> 
	<h2>READ/FETCH/ DISPLAY RECORDS FROM DATABASE</h2>
	<table border="1" width="100%">
		<tr>
			<th>name</th>
			<th>rollno</th>
			<th>email</th>
			<th>css</th>
			<th>php</th>
			<th>html</th>
			<th>Action</th>
		</tr>
		<?php 
			if ($result->num_rows > 0) {
			foreach($result as $rows){?>
				<tr>
					<td><?php echo $rows['name'];?></td>
					<td><?php echo $rows['rollno'];?></td>
					<td><?php echo $rows['email'];?></td>
					<td><?php echo $rows['css'];?></td>
					<td><?php echo $rows['php'];?></td>
					<td><?php echo $rows['html'];?></td>
					
					<td><a href="last3.php?id=<?php echo $rows['id'];?>">EDIT |</a><a href="last2.php?id=<?php echo $rows['id'];?>"> |DELETE</a> </td>
				</tr>
		<?php } }?>
	</table>

</body>
</html>