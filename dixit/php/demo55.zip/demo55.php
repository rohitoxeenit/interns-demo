<!doctype>
<html>
  <h3>odd no 1-10</h3>
  
  <body>
  <?php 
$num = 1;  
while($num<"10") {
echo "<br>";	
echo "$num";
$num+=2;
}
?>  
</body>
</html>