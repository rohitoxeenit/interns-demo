<!doctype>
<html>
<body>
<?php
$fruits=array("MANGO","APPLE","BANANA");
echo'I LIKE'.$fruits[0].",".$fruits[1].",".$fruits[2].",";
echo"<br><br>";

echo count($fruits)
	
?>
</body>
</html>