<!doctype>
<html>
<body>
<?php

$cars= array( "alto","maruti","tayota");
$a= count($cars);


for ($x = 0; $x < $a; $x++) {
 
 echo " $cars[$x]";
 echo "<br>";
}

foreach($cars as $x => $val) {
  echo "$x = $val<br>";
}



?>
