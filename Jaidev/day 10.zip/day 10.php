<?php

$h=1;
do{
    echo $h=$h+1;
} while ($h <= 5);

	echo  "<br/>";

$x = 0;
do {
	echo $x=$x+1;
} while ($x >= 5);

	echo  "<br/>";
	
$z = 0;
while($z<= 5){
	echo $z;
	$z=$z+1;
}
	echo  "<br/>";
	
for ($i = 0; $i < 10; $i++){
$product = 10 * $i;
echo " 10 * $i is $product <br/>";
}
	echo  "<br/>";

    $i = 0;
while ($i < 5){
echo $i + 1 . "<br>";
$i++;
}
?>