<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "intern";

	$conn = new mysqli('localhost', 'root', '', 'intern');
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$sql_select = "SELECT * FROM demo1";
	$result = $conn->query($sql_select);
	
	if(!empty($_GET['id'])){
		$sql_delete = "DELETE FROM demo1 WHERE id='".$_GET['id']."'";
		$result_delete = $conn->query($sql_delete);
		if($result_delete){
			echo "Record Deleted Successfully";
			header("refresh: 3; url =http://localhost/intern/demo2.php");
		} else {
			echo "Try Again";
		}
	}
	if(!empty($_GET['id'])){
		$sql_EDIT = "EDIT FROM demo1 WHERE id='".$_GET['id']."'";
		$result_EDIT= $conn->query($sql_EDIT);
		if($result_EDIT){
			echo "Record edit Successfully";
			
		} else {
			echo "Try Again";
		}
	}
 ?>
<!doctype>
<html>
<head>
</head>
<body> 
	<h2>READ/FETCH/ DISPLAY RECORDS FROM DATABASE</h2>
	<table border="1" width="100%">
		<tr>
			<th>Name</th>
			<th>Email-id</th>
			<th>Phone</th>
			<th>Gender</th>
			<th>Address</th>
			<th>Action</th>
		</tr>
		<?php 
			if ($result->num_rows > 0) {
			foreach($result as $rows){?>
				<tr>
					<td><?php echo $rows['name'];?></td>
					<td><?php echo $rows['email'];?></td>
					<td><?php echo $rows['phone'];?></td>
					<td><?php echo $rows['gender'];?></td>
					<td><?php echo $rows['address'];?></td>
					<td><a href="#">EDIT |</a><a href="demo2.php?id=<?php echo $rows['id'];?>"> |Delete</a> </td>
				</tr>
		<?php } }?>
	</table>

</body>
</html>