<?php
	$conn = new mysqli('localhost', 'root', '', 'intern');
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	$editid = $_GET['id'];
	
	$sql_fetchquery = "SELECT * FROM demo1 WHERE id='".$editid."'";
	$result_fetchdata = $conn->query($sql_fetchquery);
	$row = $result_fetchdata -> fetch_assoc();
	
	if(!empty($_POST['editsub'])){
		$sql_updatequery = "UPDATE demo1 SET name='".$_POST['name']."', rollno='".$_POST['rollno']."' email='".$_POST['email']."',html='".$_POST['html']."', css='".$_POST['css']."', php='".$_POST['php']."'".$editid."'";
		$result_updatequery = $conn->query($sql_updatequery);
		if($result_updatequery){
			echo "Record UPDATED Successfully";
			header("refresh:2; url=http://localhost/intern/demo2.php");
		} else {
			echo "Opps Record is not inserted";
		}
	}
 ?>
<center>
<form method="POST" action="">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
  Name:  
  <input type="text" name="name" value="<?php echo $row['name'];?>">
  <br><br>
 
 rollno:
  <input type="tel" name="rollno" value="<?php echo $row['rollno'];?>">
  <br><br>		
 E-mail:
  <input type="text" name="email" value="<?php echo $row['email'];?>">
  <br><br>
  html:
  <input type="text" name="html" value="<?php echo $row['html'];?>">
  <br><br>
   css:
  <input type="text" name="css" value="<?php echo $row['css'];?>">
  <br><br>
  php:
  <input type="text" name="php" value="<?php echo $row['php'];?>">
  <br><br>
  <input type="submit" value="Submit" name="editsub">
  </form>

</center>
</body>
</html>