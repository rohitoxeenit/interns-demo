<?php
$conn = new mysqli('localhost', 'root', '' ,'intern');

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if(!empty($_POST)){
	//echo "<pre>";
	//print_r($_POST);
	$name =  $_POST['name'];
	$rollno = $_POST['rollno'];
	$email = $_POST['email'];
	$html = $_POST['html'];
	$css = $_POST['css'];
	$php = $_POST['php'];
	$sql= "INSERT INTO demo1  (name,rollno, email,html,css,php) VALUES ('$name','$rollno','$email','$html','$css','$php')";
	echo $result = $conn->query($sql);
	if($result){
		echo "Successfully Insert Data";
	} else {
		echo "Opps Record is not inserted";
	}
	
}

$conn->close();
 ?>
<!doctype>
<html>
<head>
<style>
     center {
		  border:5px solid black;
		  justify-content:center;
	      diplay:flex;
	 }
	
.error {color:#ff0000;}
body { 
           background-image:url("plain1.jpg");
		  
}
</style>
</head>
<body> 
 <center>
 <form method="post" action="">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>


   student Name: <input type="text" name="name">
  
  <br><br>
  
 Roll no:
  <input type="tel" name="rollno">
  
	<br><br>		
	E-mail: <input type="text" name="email">
  
  <br><br>	
 	
	html: <input type="text" name="html">
	<br><br>	
			
	css: <input type="text" name="css">
	<br><br>	
	php: <input type="text" name="php">
	<br><br>	
	
  <input type="submit" name="submit" value="submit">
  
</form>

</center>

</body>
</html>