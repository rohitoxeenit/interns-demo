<!doctype> declare(strict_types=1); 
<html>
<body>
<h2>sorting array</h2>
<h3>sort</h3>
<?php
$cars = array("himanshu", "bini", "puunu");
sort($cars);
$c= count($cars);
for($x = 0; $x < $c; $x++) {
  echo $cars[$x];
  echo "<br>";    
}
?> 
<h2>sort in numbers</h2>
<?php
$cars = array("54", "55", "22","99","13");
sort($cars);
$c = count($cars);
for($x = 0; $x < $c; $x++) {
  echo $cars[$x];
  echo "<br>";
}
?>
<h2>rsort</h2>
<?php
$cars = array("himanshu", "bini", "puunu");
rsort($cars);
$c = count($cars);
for($x = 0; $x < $c; $x++) {
  echo $cars[$x];
  echo "<br>";
}
?> 
<h2>rsort in numbers</h2>
<?php
$cars = array("54", "55", "22","99","13");
rsort($cars);
$c = count($cars);
for($x = 0; $x < $c; $x++) {
  echo $cars[$x];
  echo "<br>";
}
?> 
<h2>asort</h2>
<?php
$age = array("himanshu"=>"19", "Bini"=>"17", "puunu"=>"20");
asort($age);
foreach($age as $x => $x_value) {
  echo "name=" . $x . ", age=" . $x_value;
  echo "<br>";
}
?>
<h2>ksort</h2>
<?php
$age = array("zzz"=>"19", "Bini"=>"17", "puunu"=>"20");
ksort($age);
foreach($age as $x => $x_value) {
  echo "name=" . $x . ", age=" . $x_value;
  echo "<br>";
}
?> 
<h2>arsort</h2>
<?php
$age = array("zzz"=>"19", "ani"=>"17", "papu"=>"20");
arsort($age);
foreach($age as $x => $x_value) {
  echo "name=" . $x . ", age=" . $x_value;
  echo "<br>";
}
?>
<h2>krsort</h2>
<?php
$age = array("zzz"=>"19", "ani"=>"17", "papu"=>"20");
krsort($age);
foreach($age as $x => $x_value) {
  echo "name=" . $x . ", age=" . $x_value;
  echo "<br>";
}
?>
<h1>functions</h1>
<?php
function name() {
  echo "himanshu";
}
name();
?>
<h1>functions argument</h1>
<?php
function naam($fname) {
  echo "$fname verma.<br>";
}
naam("himanshu");
naam("bini");
naam("punnu");
naam("varu");
naam("babu");
?>
<h1>functions with two argument</h1>
<?php
function data($fname,$years) {
  echo "$fname verma:born in:$years <br>";
}
data("himanshu","2003");
data("bini","2004");
data("punnu","2003");
data("soda","2003");
data("babu","2003");
?>
<h1>functions with integers</h1>
<?php
function addNumbers(int $a, string $b) {
return $a + $b;
}
echo addNumbers(5, "30days");
?>
<h1>functions with strict integers</h1>
<?php// declare(strict_types=1); // strict requirement

//function addNumbers(int $a, int $b) {
//return $a + $b;
//}
//echo addNumbers(5,"5 days"); 
?>
<h1>functions with default value</h1>
<?php
function setHeight(int $minheight = 222) {
  echo "The height is : $minheight <br>";
}
setHeight(111);
setHeight();
setHeight(333);
setHeight(444);
?>
<h1>functions with default value</h1>
<?php
function sum(int $x, int $y) {
  $z = $x * $y;
  return $z;
}
echo "4 * 1 = ". sum(4, 1) . "<br>";
echo "4 * 2 = ". sum(4, 2) . "<br>";
echo "4 * 3 = ". sum(4, 3) . "<br>";
echo "4 * 4 = ". sum(4, 4) . "<br>";
echo "4 * 5 = ". sum(4, 5) . "<br>";
echo "4 * 6 = ". sum(4, 6) . "<br>";
echo "4 * 7 = ". sum(4, 7) . "<br>";
echo "4 * 8 = ". sum(4, 8) . "<br>";
echo "4 * 9 = ". sum(4, 9) . "<br>";
echo "4 * 10 = ". sum(4, 10) . "<br>";
?>
<h1>functions with default value</h1>
<?php  
function Numbers(float $a, float $b) : float {
  return $a + $b;
}
echo Numbers(32.1, 37.8); 
?>
 declare(strict_types=1); 
function addNumbers(float $a, float $b) : float {
  return $a + $b;
}
echo addNumbers(32.1, 37.8); 
