<?php
	$conn = new mysqli('localhost', 'root', '', 'intern');
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	$editid = $_GET['id'];
	
	$sql_fetchquery = "SELECT * FROM demo1 WHERE id='".$editid."'";
	$result_fetchdata = $conn->query($sql_fetchquery);
	$row = $result_fetchdata -> fetch_assoc();
	
	if(!empty($_POST['editsub'])){
		$sql_updatequery = "UPDATE demo1 SET name='".$_POST['name']."', email='".$_POST['email']."', phone='".$_POST['phone']."', address='".$_POST['address']."' WHERE id='".$editid."'";
		$result_updatequery = $conn->query($sql_updatequery);
		if($result_updatequery){
			echo "Record UPDATED Successfully";
			header("refresh:2; url=http://localhost/intern/demo2.php");
		} else {
			echo "Opps Record is not inserted";
		}
	}
 ?>
<center>
<form method="POST" action="">  
<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
  Name:  
  <input type="text" name="name" value="<?php echo $row['name'];?>">
  <br><br>
  E-mail:
  <input type="text" name="email" value="<?php echo $row['email'];?>">
  <br><br>
  phone:
  <input type="tel" name="phone" value="<?php echo $row['phone'];?>">
  <br><br>		
  GENDER:
  <input type="radio" name="gender" value="male">male
  <input type="radio" name="gender" value="female">female
  <br><br>
  address: <textarea name="address" rows="5" cols="20"> <?php echo $row['address'];?></textarea>
  <br><br>
  <input type="submit" value="Submit" name="editsub">
  </form>

</center>
</body>
</html>