<!DOCTYPE HTML>  
<html>
<head>
<style>
center{
	display:flex;
	justify-content:center;
  border: 10px solid black;
  background-color: lightblue;
}
div{
	cellpadding:10px;
	
	
}
.error {color: #FF0000;}

div{
  background-image: url("plain1.jpeg");

}
</style>
</head>
<body> 
<center>
<div class =center;>
<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $numberErr =$addressErr ="";
$name = $email = $gender = $address  =$education = $number = $skills  = "";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (empty($_GET["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_GET["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_GET["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_GET["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
  
  if (empty($_GET["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_GET["gender"]);
  }
}
if (empty($_GET["address"])) {
    $address = "address needed";
    } else {
    $address = test_input($_GET["address"]);
    // check if e-mail address is well-formed
 if (!preg_match("/^[a-zA-Z-' ]*$/",$address)) {
      $addressErr = "Invalid address format";
    }
  }
if (empty($_GET["number"])) {
    $numberErr = "Number is required";
  } else {
    $number = test_input($_GET["number"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$number)) {
      
    }
  }

   if (empty($_GET["education"])) {
    $education = "";
  } else {
    $education = test_input($_GET["education"]);
  }
     if (empty($_GET["skills"])) {
    $skills = "";
  } else {
    $skills = test_input($_GET["skills"]);
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">*  </span></p>
<form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Name: <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  number: <input number="tel" name="number">
 <span class="error">* <?php echo $numberErr;?></span>
  <br><br>
  address: <textarea name="address" rows="5" cols="40"></textarea>
  <span class="error">* <?php echo $addressErr;?></span>
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  
 Select COURCE
          <select name="education">
        	<option value="mca">MCA</option>
          	<option value="bca">BCA</option>
          	<option value="mba">MBA</option>
         	<option value="bba">BBA</option>  
           </select>
		   <br><br>
		   
		skills:	  
		   <input type="checkbox" name="skills" value="html">html
		   <input type="checkbox" name="skills" value="php">php
		   <input type="checkbox" name="skills" value="css">css
		   <input type="checkbox" name="skills" value="bootstrap">bootsrap
		   <input type="checkbox" name="skills" value="java ">java
		   <br><br>
 <input type="submit" name="submit" value="Submit">  
 <input type="reset" name="reset" value="reset">  
 

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $education;
echo "<br>";
echo $number;
echo "<br>";
echo $address;
echo "<br>";
echo $gender;
echo "<br>";
echo $skills;
echo "<br>";

?>
</form>

</div>
</body>
</html>